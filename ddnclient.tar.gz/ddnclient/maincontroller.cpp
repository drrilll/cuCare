#include "maincontroller.h"
#include "storage/cuclientsocket.h"

MainController::MainController()
{
    currentPatient = 0;
    currentConsult = 0;
    storage = new cuClientSocket();
    patients = new QList<Patient>();
    consults = new QList<Consultation>();
    followups = new QList<Followup>();

    user = new User();
    login = new LoginDialog(storage, user, this);
    login->setFixedSize(400,226);
    login->show();

    mainWindow = new MainWindow(this);
    patwindow = new PatientWindow(this);
    filterPatientDB = new filterPatientDialogBox(this, mainWindow);
    consultwindow = new ConsultWindow(this);
    followupwindow = new FollowupWindow(this);
    followupwidget = followupwindow->getFollowupWidget();
    mainWindowSA = new MainWindowSA(this);
    configAPDialog = new configAuditParametersDialog(this,mainWindow);

    filter = false;

    filterColour = new QColor(0,150,255);
}

MainController::~MainController(){
    delete storage;
    delete user;
    delete patients;
    delete consults;
    delete followups;
    delete mainWindow;
    delete mainWindowSA;
    delete configAPDialog;
}

//setters
void MainController::setPatients(QList<Patient> *patients){
    this->patients = patients;
}

void MainController::setConsults(QList<Consultation> *consults){
    this->consults = consults;
}

void MainController::setCurrentPatient(Patient* patient){
    currentPatient = patient;
}

void MainController::setCurrentConsult(Consultation* consult){
    currentConsult = consult;
}

void MainController::setFilter(qint32 physIDFilter, Status statusFilter){
    this->physIDFilter = physIDFilter;
    this->statusFilter = statusFilter;
    filter = true;
}

void MainController::removeFilter(){
    filter = false;
}

void MainController::setColor(QColor color){
    delete filterColour;
    filterColour = new QColor(color);
}


//getters
QList<Patient> *MainController::getPatients(){
    return patients;
}

QList<Consultation> *MainController::getConsults(){
    return consults;
}

QList<Followup> *MainController::getFollowups(){
    return followups;
}

Patient ** MainController::getCurrentPatient(){
    return &currentPatient;
}

Consultation **MainController::getCurrentConsult(){
    return &currentConsult;
}

Followup **MainController::getCurrentFollowup(){
    return &currentFollowup;
}

cuStore * MainController::getStorage(){
    return storage;
}

User * MainController::getUser(){
    return user;
}

bool MainController::isFiltering(){
    return filter;
}

qint32 MainController::getPhysIDFilter(){
    return physIDFilter;
}

Status MainController::getStatusFilter(){
    return statusFilter;
}
QColor * MainController::getFilterColour(){
    return filterColour;
}

MainWindow * MainController::getMainWindow(){
    return mainWindow;
}


//etc
void MainController::addPatient(Patient* pat){
    patients->push_back(*pat);
}

void MainController::exitPatientWindow(){
    //patwindow->clearPatientForm();
    filter=false;
    patwindow->close();
    mainWindow->open();
}


void MainController::exitConsultWindow(){
    consultwindow->close();
    patwindow->open();
}

void MainController::exitFollowupWindow(){
    followupwindow->close();
    consultwindow->open();
}

void MainController:: exitConfigAuditParams(){
    configAPDialog->close();
   // mainWindowSA->open();
}

void MainController::openPatientWindow(){
    mainWindow->close();
    qDebug("opening patient window");
    currentPatient = 0;  
    patwindow->open();
}

void MainController::openFollowupWindow(){
    // i==0: New FollowUp | i==1: Display FollowUps
    consultwindow->close();
    currentFollowup = 0;
    followupwindow->open();
}

void MainController::openConsultWindow(){
    patwindow->close();
    currentConsult = 0;
    consultwindow->open();
}

void MainController::openFilterPatientDialogBox(){
    qDebug("OPENING FILTER PATIENT DIALOGBOX");
    filterPatientDB->exec();
    openPatientWindow();
}

void MainController::openConfigureAuditParametersDialogBox(){
    qDebug("OPENING CONFIGURE AUDIT PARAMETERS DIALOGBOX");
    //mainWindowSA->close();
    //configAPDialog->open();
    //configAPDialog = new configAuditParametersDialog(this, mainWindowSA);
    configAPDialog->exec();
}

void MainController::loginSuccess(){
    login->done(0);
    if((user->getType()==1)||(user->getType()==2)) {mainWindow->open();}
    if(user->getType()==3) {mainWindowSA->open();}
}


void MainController::logout(){
    mainWindow->close();
    mainWindowSA->close();

    login->show();
}


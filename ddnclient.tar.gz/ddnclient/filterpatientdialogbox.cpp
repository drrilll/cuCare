#include "filterpatientdialogbox.h"
#include "ui_filterpatientdialogbox.h"

filterPatientDialogBox::filterPatientDialogBox(MainController *control, QWidget *parent) :
    QDialog(parent),
    ui(new Ui::filterPatientDialogBox)
{
    ui->setupUi(this);
    this->control = control;
}

filterPatientDialogBox::~filterPatientDialogBox()
{
    delete ui;
}

void filterPatientDialogBox::on_buttonBox_accepted()
{
    QString physIDChosenQString = ui->physicianIDEnter->text();
    qDebug("=====================on_buttonBox_accepted(): physIDChosen=============");
    int physIDChosen = physIDChosenQString.toInt();
    QString temp;
    temp.setNum(physIDChosen);
    qDebug(temp.toStdString().c_str());

    int followUpStatusChosen = ui->followUpComboBox->currentIndex();
    /* FOR TESTING -- WILL GET: 0-all, 1-pending, 2-overdue, 3-results received, 4-complete
    QString followUpStatusChosenQString;
    followUpStatusChosenQString.setNum(followUpStatusChosen);
    qDebug(followUpStatusChosenQString.toStdString().c_str());
    */
    qDebug("=====================on_buttonBox_accepted(): status=============");
    QString tempID;
    tempID.setNum(followUpStatusChosen);
    qDebug(tempID.toStdString().c_str());

    control->setFilter(physIDChosen,(Status)followUpStatusChosen);

    control->getPatients()->clear();
    control->getStorage()->searchPatientsByFollowupStatus(*(control->getPatients()),(Status)followUpStatusChosen,physIDChosen);

}

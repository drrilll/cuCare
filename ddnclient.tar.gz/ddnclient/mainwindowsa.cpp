#include "mainwindowsa.h"
#include "ui_mainwindowsa.h"

MainWindowSA::MainWindowSA(MainController *control, QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindowSA)
{
    this->control = control;
    this->user = control->getUser();
    this->storage = control->getStorage();

    ui->setupUi(this);
}

MainWindowSA::~MainWindowSA()
{
    delete ui;
}
void MainWindowSA::open(){
    qDebug("============ MainWindowSA::open() ===================");
    this->user = control->getUser();
    qDebug(user->getUserName().toStdString().c_str());
    ui->loggedInShow->setText(user->getUserName());
    ui->userTypeShow->setText("System Administrator");

    QString title;

    title.append("cuCare logged in as ").append(user->getUserName());
    this->setWindowTitle(title);

    this->setFixedSize(638,152);

    show();
}

void MainWindowSA::on_configureAuditButton_clicked()
{
    control->openConfigureAuditParametersDialogBox();
}

void MainWindowSA::on_logOutButton_clicked()
{
    control->logout();
}

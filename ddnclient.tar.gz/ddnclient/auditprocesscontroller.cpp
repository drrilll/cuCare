#include "auditprocesscontroller.h"

AuditProcessController::AuditProcessController(MainController * control)
{
    this->control=control;
}

void AuditProcessController::setAuditTime(QTime time){
    control->getStorage()->setAudit(time);
}

#include <QtGui/QApplication>
#include "storage/cuclientsocket.h"
#include "maincontroller.h"
#include "logindialog.h"

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);

    MainController controller;

    return a.exec();
}

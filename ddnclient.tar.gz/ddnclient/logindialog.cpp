#include "logindialog.h"
#include "ui_logindialog.h"


LoginDialog::LoginDialog(cuStore * storage, User *user, MainController *main, QWidget *parent) :
    QDialog(parent),
    ui(new Ui::LoginDialog)
{
    ui->setupUi(this);
    this->storage = storage;
    this->user = user;
    this->main = main;
}


LoginDialog::~LoginDialog()
{
    delete ui;

}

void LoginDialog::on_buttonBox_accepted()
{
    user->setUserID(-1);

    qDebug("============LoginDialog::on_buttonBox_accepted()==============");
    //qDebug(user->getType().toStdString().c_str());
    qDebug(user->getUserName().toStdString().c_str());

    errorType t;

    LoginController *loginControl = new LoginController(main);
    t = loginControl->getUser(ui->uname->text());

    if (t!=OK){
        //you fail
        qDebug("Failed Case");
        if (t == recordNotFound){
            QMessageBox::warning( this, "Warning",
                                  "No user found by that name",
                                  "OK",0);
        }else{
            QMessageBox::warning( this, "Warning",
                                  "No connection. Is server running?",
                                  "OK",0);
        }
    }else{
        //success
        qDebug("%d",user->getUserID());
        qDebug("Not Failed Case");
        main->loginSuccess();
    }
    qDebug("============LoginDialog::on_buttonBox_accepted()  2  ==============");
    qDebug(user->getUserName().toStdString().c_str());

    delete loginControl;

}


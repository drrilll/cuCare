#ifndef AUDITPROCESSCONTROLLER_H
#define AUDITPROCESSCONTROLLER_H

#include <maincontroller.h>


class AuditProcessController
{
public:
    AuditProcessController(MainController * control);

    void setAuditTime(QTime time);

private:
    MainController * control;
};

#endif // AUDITPROCESSCONTROLLER_H

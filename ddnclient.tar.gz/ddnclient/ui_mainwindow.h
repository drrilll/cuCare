/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created: Mon Dec 3 23:37:17 2012
**      by: Qt User Interface Compiler version 4.8.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QLineEdit>
#include <QtGui/QMainWindow>
#include <QtGui/QMenu>
#include <QtGui/QMenuBar>
#include <QtGui/QPushButton>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QAction *actionPick_a_colour;
    QWidget *centralwidget;
    QLabel *label;
    QLabel *label_2;
    QPushButton *searchfullname;
    QPushButton *newpatient;
    QPushButton *filterPatientList;
    QLabel *loggedInAsLabel;
    QLabel *loggedInShow;
    QLabel *userTypeLabel;
    QLabel *userTypeShow;
    QLineEdit *fname;
    QLabel *label_3;
    QLabel *label_4;
    QLabel *label_5;
    QLineEdit *lname;
    QLineEdit *healthcard;
    QPushButton *searchfname;
    QPushButton *searchlname;
    QPushButton *searchhcard;
    QPushButton *logOutButton;
    QPushButton *manageUserButton_2;
    QMenuBar *menuBar;
    QMenu *menuUI_Settings;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QString::fromUtf8("MainWindow"));
        MainWindow->resize(686, 246);
        MainWindow->setWindowOpacity(0);
        actionPick_a_colour = new QAction(MainWindow);
        actionPick_a_colour->setObjectName(QString::fromUtf8("actionPick_a_colour"));
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        label = new QLabel(centralwidget);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(10, 20, 391, 51));
        QFont font;
        font.setFamily(QString::fromUtf8("Bitstream Charter"));
        font.setPointSize(24);
        font.setBold(true);
        font.setWeight(75);
        label->setFont(font);
        label_2 = new QLabel(centralwidget);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(430, 130, 131, 21));
        searchfullname = new QPushButton(centralwidget);
        searchfullname->setObjectName(QString::fromUtf8("searchfullname"));
        searchfullname->setGeometry(QRect(430, 200, 111, 31));
        newpatient = new QPushButton(centralwidget);
        newpatient->setObjectName(QString::fromUtf8("newpatient"));
        newpatient->setGeometry(QRect(20, 110, 97, 27));
        filterPatientList = new QPushButton(centralwidget);
        filterPatientList->setObjectName(QString::fromUtf8("filterPatientList"));
        filterPatientList->setGeometry(QRect(120, 110, 131, 27));
        loggedInAsLabel = new QLabel(centralwidget);
        loggedInAsLabel->setObjectName(QString::fromUtf8("loggedInAsLabel"));
        loggedInAsLabel->setGeometry(QRect(430, 10, 91, 21));
        loggedInShow = new QLabel(centralwidget);
        loggedInShow->setObjectName(QString::fromUtf8("loggedInShow"));
        loggedInShow->setGeometry(QRect(520, 10, 141, 21));
        userTypeLabel = new QLabel(centralwidget);
        userTypeLabel->setObjectName(QString::fromUtf8("userTypeLabel"));
        userTypeLabel->setGeometry(QRect(430, 30, 61, 21));
        userTypeShow = new QLabel(centralwidget);
        userTypeShow->setObjectName(QString::fromUtf8("userTypeShow"));
        userTypeShow->setGeometry(QRect(520, 30, 151, 21));
        fname = new QLineEdit(centralwidget);
        fname->setObjectName(QString::fromUtf8("fname"));
        fname->setGeometry(QRect(160, 150, 248, 26));
        label_3 = new QLabel(centralwidget);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setGeometry(QRect(20, 160, 141, 16));
        label_4 = new QLabel(centralwidget);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        label_4->setGeometry(QRect(20, 190, 131, 16));
        label_5 = new QLabel(centralwidget);
        label_5->setObjectName(QString::fromUtf8("label_5"));
        label_5->setGeometry(QRect(20, 220, 131, 16));
        lname = new QLineEdit(centralwidget);
        lname->setObjectName(QString::fromUtf8("lname"));
        lname->setGeometry(QRect(160, 180, 248, 26));
        healthcard = new QLineEdit(centralwidget);
        healthcard->setObjectName(QString::fromUtf8("healthcard"));
        healthcard->setGeometry(QRect(160, 210, 248, 26));
        searchfname = new QPushButton(centralwidget);
        searchfname->setObjectName(QString::fromUtf8("searchfname"));
        searchfname->setGeometry(QRect(430, 160, 111, 31));
        searchlname = new QPushButton(centralwidget);
        searchlname->setObjectName(QString::fromUtf8("searchlname"));
        searchlname->setGeometry(QRect(550, 160, 111, 31));
        searchhcard = new QPushButton(centralwidget);
        searchhcard->setObjectName(QString::fromUtf8("searchhcard"));
        searchhcard->setGeometry(QRect(550, 200, 111, 31));
        logOutButton = new QPushButton(centralwidget);
        logOutButton->setObjectName(QString::fromUtf8("logOutButton"));
        logOutButton->setGeometry(QRect(430, 60, 231, 31));
        manageUserButton_2 = new QPushButton(centralwidget);
        manageUserButton_2->setObjectName(QString::fromUtf8("manageUserButton_2"));
        manageUserButton_2->setEnabled(false);
        manageUserButton_2->setGeometry(QRect(260, 110, 101, 27));
        MainWindow->setCentralWidget(centralwidget);
        menuBar = new QMenuBar(MainWindow);
        menuBar->setObjectName(QString::fromUtf8("menuBar"));
        menuBar->setGeometry(QRect(0, 0, 686, 24));
        menuUI_Settings = new QMenu(menuBar);
        menuUI_Settings->setObjectName(QString::fromUtf8("menuUI_Settings"));
        MainWindow->setMenuBar(menuBar);

        menuBar->addAction(menuUI_Settings->menuAction());
        menuUI_Settings->addAction(actionPick_a_colour);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "MainWindow", 0, QApplication::UnicodeUTF8));
        actionPick_a_colour->setText(QApplication::translate("MainWindow", "pick a colour", 0, QApplication::UnicodeUTF8));
        label->setText(QApplication::translate("MainWindow", "<html><head/><body><p align=\"center\"><span style=\" font-size:28pt;\">Welcome to cuCare</span></p></body></html>", 0, QApplication::UnicodeUTF8));
        label_2->setText(QApplication::translate("MainWindow", "<html><head/><body><p><span style=\" font-weight:600;\">Search a Patient by:</span></p></body></html>", 0, QApplication::UnicodeUTF8));
        searchfullname->setText(QApplication::translate("MainWindow", "Full Name", 0, QApplication::UnicodeUTF8));
        newpatient->setText(QApplication::translate("MainWindow", "New Patient", 0, QApplication::UnicodeUTF8));
        filterPatientList->setText(QApplication::translate("MainWindow", "Filter Patient List", 0, QApplication::UnicodeUTF8));
        loggedInAsLabel->setText(QApplication::translate("MainWindow", "<html><head/><body><p><span style=\" font-weight:600; font-style:italic;\">Logged in as:</span></p></body></html>", 0, QApplication::UnicodeUTF8));
        loggedInShow->setText(QString());
        userTypeLabel->setText(QApplication::translate("MainWindow", "<html><head/><body><p><span style=\" font-weight:600; font-style:italic;\">I am a(n):</span></p></body></html>", 0, QApplication::UnicodeUTF8));
        userTypeShow->setText(QString());
        label_3->setText(QApplication::translate("MainWindow", "<html><head/><body><p><span style=\" font-weight:600;\">Patient First Name</span></p></body></html>", 0, QApplication::UnicodeUTF8));
        label_4->setText(QApplication::translate("MainWindow", "<html><head/><body><p><span style=\" font-weight:600;\">Patient Last Name</span></p></body></html>", 0, QApplication::UnicodeUTF8));
        label_5->setText(QApplication::translate("MainWindow", "<html><head/><body><p><span style=\" font-weight:600;\">Health Card Number</span></p></body></html>", 0, QApplication::UnicodeUTF8));
        searchfname->setText(QApplication::translate("MainWindow", "First Name", 0, QApplication::UnicodeUTF8));
        searchlname->setText(QApplication::translate("MainWindow", "Last Name", 0, QApplication::UnicodeUTF8));
        searchhcard->setText(QApplication::translate("MainWindow", "Health Card #", 0, QApplication::UnicodeUTF8));
        logOutButton->setText(QApplication::translate("MainWindow", "Log out", 0, QApplication::UnicodeUTF8));
        manageUserButton_2->setText(QApplication::translate("MainWindow", "Run Statistics", 0, QApplication::UnicodeUTF8));
        menuUI_Settings->setTitle(QApplication::translate("MainWindow", "UI Settings", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H

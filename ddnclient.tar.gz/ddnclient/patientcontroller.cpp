#include "patientcontroller.h"

PatientController::PatientController(MainController *control)
{
    this->control = control;
    this->currentPatient = *(control->getCurrentPatient());
}

errorType PatientController::savePatient(bool update){
    errorType t;
    if (update){
        t = control->getStorage()->updatePatient(*currentPatient);
    }else{
        t =  control->getStorage()->saveNewPatient(*currentPatient);
    }
    return t;
}

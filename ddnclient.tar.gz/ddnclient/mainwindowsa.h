#ifndef MAINWINDOWSA_H
#define MAINWINDOWSA_H

#include <QMainWindow>
#include "storage/custore.h"
#include "maincontroller.h"

namespace Ui {
class MainWindowSA;
}

class MainWindowSA : public QMainWindow
{
    Q_OBJECT
    
public:
    explicit MainWindowSA(MainController *control, QWidget *parent = 0);
    ~MainWindowSA();

   void open();
    
private slots:
   void on_configureAuditButton_clicked();

   void on_logOutButton_clicked();

private:
    Ui::MainWindowSA *ui;

    cuStore *storage;
    User *user;
    MainController * control;
};

#endif // MAINWINDOWSA_H

#include "followupwindow.h"
#include "ui_followupwindow.h"
#include "followupwidget.h"

FollowupWindow::FollowupWindow(MainController * control, QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::FollowupWindow)
{
    ui->setupUi(this);
    fupwidget = new FollowupWidget(control, this);
    ui->centralwidget = fupwidget;
    this->control = control;
}

FollowupWindow::~FollowupWindow()
{
    delete ui;
}

void FollowupWindow::open(){
    // i==0: New FollowUp | i==1: Display FollowUps
    fupwidget->initializeWithNewConsultation();

    this->setPalette( this->style()->standardPalette());
    this->setWindowTitle("Follow-Up Window");

    if(control->isFiltering()) {
        this->setPalette( QPalette( *(control->getFilterColour()) ) );

        QString status;
        QString physID;

        switch(control->getStatusFilter()){
            case 0: status.append("All"); break;
            case 1: status.append("Pending"); break;
            case 2: status.append("Overdue"); break;
            case 3: status.append("Results Recieved"); break;
            case 4: status.append("Complete"); break;
        }

        physID.setNum(control->getPhysIDFilter());

        QString title;

        title.append("Filter Patient by (Status: ").append(status).append(" && Physician ID: ").append(physID).append(")");
        this->setWindowTitle(title);
    }

    this->setFixedSize(773,642);
    show();
}

FollowupWidget *FollowupWindow::getFollowupWidget(){
    return fupwidget;
}

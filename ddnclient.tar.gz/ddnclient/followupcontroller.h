#ifndef FOLLOWUPCONTROLLER_H
#define FOLLOWUPCONTROLLER_H
#include <maincontroller.h>


class FollowupController
{
public:
    FollowupController(MainController * control);

    errorType saveFollowup(bool update);

private:
    MainController * control;
    QList<Followup> * followUps;
};

#endif // FOLLOWUPCONTROLLER_H

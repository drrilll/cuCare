#ifndef LOGINCONTROLLER_H
#define LOGINCONTROLLER_H
#include <maincontroller.h>


class LoginController
{
public:
    LoginController(MainController * control);

    errorType getUser(QString a);

private:
    MainController * control;
    User * user;
};

#endif // LOGINCONTROLLER_H

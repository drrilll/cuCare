/********************************************************************************
** Form generated from reading UI file 'followupwindow.ui'
**
** Created: Mon Dec 3 22:32:11 2012
**      by: Qt User Interface Compiler version 4.8.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_FOLLOWUPWINDOW_H
#define UI_FOLLOWUPWINDOW_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QHeaderView>
#include <QtGui/QMainWindow>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_FollowupWindow
{
public:
    QWidget *centralwidget;

    void setupUi(QMainWindow *FollowupWindow)
    {
        if (FollowupWindow->objectName().isEmpty())
            FollowupWindow->setObjectName(QString::fromUtf8("FollowupWindow"));
        FollowupWindow->resize(773, 642);
        centralwidget = new QWidget(FollowupWindow);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        FollowupWindow->setCentralWidget(centralwidget);

        retranslateUi(FollowupWindow);

        QMetaObject::connectSlotsByName(FollowupWindow);
    } // setupUi

    void retranslateUi(QMainWindow *FollowupWindow)
    {
        FollowupWindow->setWindowTitle(QApplication::translate("FollowupWindow", "Follow-up WIndow", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class FollowupWindow: public Ui_FollowupWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_FOLLOWUPWINDOW_H

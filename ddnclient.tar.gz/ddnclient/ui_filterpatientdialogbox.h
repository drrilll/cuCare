/********************************************************************************
** Form generated from reading UI file 'filterpatientdialogbox.ui'
**
** Created: Mon Dec 3 22:32:11 2012
**      by: Qt User Interface Compiler version 4.8.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_FILTERPATIENTDIALOGBOX_H
#define UI_FILTERPATIENTDIALOGBOX_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QComboBox>
#include <QtGui/QDialog>
#include <QtGui/QDialogButtonBox>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QLineEdit>

QT_BEGIN_NAMESPACE

class Ui_filterPatientDialogBox
{
public:
    QDialogButtonBox *buttonBox;
    QLabel *FollowUpStatusLabel;
    QLabel *PhysicianLabel;
    QComboBox *followUpComboBox;
    QLineEdit *physicianIDEnter;

    void setupUi(QDialog *filterPatientDialogBox)
    {
        if (filterPatientDialogBox->objectName().isEmpty())
            filterPatientDialogBox->setObjectName(QString::fromUtf8("filterPatientDialogBox"));
        filterPatientDialogBox->resize(400, 185);
        buttonBox = new QDialogButtonBox(filterPatientDialogBox);
        buttonBox->setObjectName(QString::fromUtf8("buttonBox"));
        buttonBox->setGeometry(QRect(40, 140, 341, 32));
        buttonBox->setOrientation(Qt::Horizontal);
        buttonBox->setStandardButtons(QDialogButtonBox::Cancel|QDialogButtonBox::Ok);
        FollowUpStatusLabel = new QLabel(filterPatientDialogBox);
        FollowUpStatusLabel->setObjectName(QString::fromUtf8("FollowUpStatusLabel"));
        FollowUpStatusLabel->setGeometry(QRect(30, 60, 121, 27));
        PhysicianLabel = new QLabel(filterPatientDialogBox);
        PhysicianLabel->setObjectName(QString::fromUtf8("PhysicianLabel"));
        PhysicianLabel->setGeometry(QRect(30, 30, 121, 27));
        followUpComboBox = new QComboBox(filterPatientDialogBox);
        followUpComboBox->setObjectName(QString::fromUtf8("followUpComboBox"));
        followUpComboBox->setGeometry(QRect(170, 60, 212, 27));
        physicianIDEnter = new QLineEdit(filterPatientDialogBox);
        physicianIDEnter->setObjectName(QString::fromUtf8("physicianIDEnter"));
        physicianIDEnter->setGeometry(QRect(170, 30, 210, 27));

        retranslateUi(filterPatientDialogBox);
        QObject::connect(buttonBox, SIGNAL(accepted()), filterPatientDialogBox, SLOT(accept()));
        QObject::connect(buttonBox, SIGNAL(rejected()), filterPatientDialogBox, SLOT(reject()));

        QMetaObject::connectSlotsByName(filterPatientDialogBox);
    } // setupUi

    void retranslateUi(QDialog *filterPatientDialogBox)
    {
        filterPatientDialogBox->setWindowTitle(QApplication::translate("filterPatientDialogBox", "Filter Patient List", 0, QApplication::UnicodeUTF8));
        FollowUpStatusLabel->setText(QApplication::translate("filterPatientDialogBox", "Follow Up Status", 0, QApplication::UnicodeUTF8));
        PhysicianLabel->setText(QApplication::translate("filterPatientDialogBox", "Physician ID", 0, QApplication::UnicodeUTF8));
        followUpComboBox->clear();
        followUpComboBox->insertItems(0, QStringList()
         << QApplication::translate("filterPatientDialogBox", "All", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("filterPatientDialogBox", "Pending", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("filterPatientDialogBox", "Overdue", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("filterPatientDialogBox", "Results Received", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("filterPatientDialogBox", "Complete", 0, QApplication::UnicodeUTF8)
        );
    } // retranslateUi

};

namespace Ui {
    class filterPatientDialogBox: public Ui_filterPatientDialogBox {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_FILTERPATIENTDIALOGBOX_H

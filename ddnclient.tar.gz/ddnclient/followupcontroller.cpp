#include "followupcontroller.h"

FollowupController::FollowupController(MainController *control)
{
    this->control = control;
    followUps = control->getFollowups();
}

errorType FollowupController::saveFollowup(bool update){
    errorType t;
    Followup *currentFollowUp = *(control->getCurrentFollowup());
    if (update){
        t = control->getStorage()->updateFollowup(*currentFollowUp);
    }else{
        t = control->getStorage()->saveNewFollowup(*currentFollowUp);
    }
    return t;
}

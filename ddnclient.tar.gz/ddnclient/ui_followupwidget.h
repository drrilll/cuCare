/********************************************************************************
** Form generated from reading UI file 'followupwidget.ui'
**
** Created: Mon Dec 3 22:32:11 2012
**      by: Qt User Interface Compiler version 4.8.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_FOLLOWUPWIDGET_H
#define UI_FOLLOWUPWIDGET_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QComboBox>
#include <QtGui/QDateEdit>
#include <QtGui/QFormLayout>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QLineEdit>
#include <QtGui/QPushButton>
#include <QtGui/QScrollArea>
#include <QtGui/QTableWidget>
#include <QtGui/QTextEdit>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_FollowupWidget
{
public:
    QWidget *formLayoutWidget;
    QFormLayout *formLayout;
    QLabel *label;
    QLineEdit *patientfname;
    QLineEdit *patientID;
    QLabel *label_3;
    QLabel *label_9;
    QLineEdit *patientlname;
    QWidget *formLayoutWidget_2;
    QFormLayout *formLayout_2;
    QLabel *label_4;
    QLineEdit *physfname;
    QLineEdit *physID;
    QLabel *label_10;
    QLabel *label_11;
    QLineEdit *physlname;
    QWidget *formLayoutWidget_3;
    QFormLayout *formLayout_3;
    QLabel *label_5;
    QTextEdit *description;
    QLabel *label_7;
    QTextEdit *results;
    QPushButton *save;
    QLabel *label_2;
    QLabel *label_12;
    QLabel *label_13;
    QPushButton *back;
    QScrollArea *scrollArea;
    QWidget *scrollAreaWidgetContents;
    QTableWidget *tableWidget;
    QLabel *followUpTitle;
    QLabel *label_8;
    QComboBox *status;
    QLabel *label_6;
    QDateEdit *date;
    QLabel *followUpNumberLabel;

    void setupUi(QWidget *FollowupWidget)
    {
        if (FollowupWidget->objectName().isEmpty())
            FollowupWidget->setObjectName(QString::fromUtf8("FollowupWidget"));
        FollowupWidget->resize(772, 639);
        formLayoutWidget = new QWidget(FollowupWidget);
        formLayoutWidget->setObjectName(QString::fromUtf8("formLayoutWidget"));
        formLayoutWidget->setGeometry(QRect(10, 80, 311, 101));
        formLayout = new QFormLayout(formLayoutWidget);
        formLayout->setObjectName(QString::fromUtf8("formLayout"));
        formLayout->setContentsMargins(0, 0, 0, 0);
        label = new QLabel(formLayoutWidget);
        label->setObjectName(QString::fromUtf8("label"));

        formLayout->setWidget(0, QFormLayout::LabelRole, label);

        patientfname = new QLineEdit(formLayoutWidget);
        patientfname->setObjectName(QString::fromUtf8("patientfname"));

        formLayout->setWidget(0, QFormLayout::FieldRole, patientfname);

        patientID = new QLineEdit(formLayoutWidget);
        patientID->setObjectName(QString::fromUtf8("patientID"));

        formLayout->setWidget(2, QFormLayout::FieldRole, patientID);

        label_3 = new QLabel(formLayoutWidget);
        label_3->setObjectName(QString::fromUtf8("label_3"));

        formLayout->setWidget(2, QFormLayout::LabelRole, label_3);

        label_9 = new QLabel(formLayoutWidget);
        label_9->setObjectName(QString::fromUtf8("label_9"));

        formLayout->setWidget(1, QFormLayout::LabelRole, label_9);

        patientlname = new QLineEdit(formLayoutWidget);
        patientlname->setObjectName(QString::fromUtf8("patientlname"));

        formLayout->setWidget(1, QFormLayout::FieldRole, patientlname);

        formLayoutWidget_2 = new QWidget(FollowupWidget);
        formLayoutWidget_2->setObjectName(QString::fromUtf8("formLayoutWidget_2"));
        formLayoutWidget_2->setGeometry(QRect(330, 80, 301, 101));
        formLayout_2 = new QFormLayout(formLayoutWidget_2);
        formLayout_2->setObjectName(QString::fromUtf8("formLayout_2"));
        formLayout_2->setContentsMargins(0, 0, 0, 0);
        label_4 = new QLabel(formLayoutWidget_2);
        label_4->setObjectName(QString::fromUtf8("label_4"));

        formLayout_2->setWidget(2, QFormLayout::LabelRole, label_4);

        physfname = new QLineEdit(formLayoutWidget_2);
        physfname->setObjectName(QString::fromUtf8("physfname"));

        formLayout_2->setWidget(0, QFormLayout::FieldRole, physfname);

        physID = new QLineEdit(formLayoutWidget_2);
        physID->setObjectName(QString::fromUtf8("physID"));

        formLayout_2->setWidget(2, QFormLayout::FieldRole, physID);

        label_10 = new QLabel(formLayoutWidget_2);
        label_10->setObjectName(QString::fromUtf8("label_10"));

        formLayout_2->setWidget(0, QFormLayout::LabelRole, label_10);

        label_11 = new QLabel(formLayoutWidget_2);
        label_11->setObjectName(QString::fromUtf8("label_11"));

        formLayout_2->setWidget(1, QFormLayout::LabelRole, label_11);

        physlname = new QLineEdit(formLayoutWidget_2);
        physlname->setObjectName(QString::fromUtf8("physlname"));

        formLayout_2->setWidget(1, QFormLayout::FieldRole, physlname);

        formLayoutWidget_3 = new QWidget(FollowupWidget);
        formLayoutWidget_3->setObjectName(QString::fromUtf8("formLayoutWidget_3"));
        formLayoutWidget_3->setGeometry(QRect(10, 220, 621, 171));
        formLayout_3 = new QFormLayout(formLayoutWidget_3);
        formLayout_3->setObjectName(QString::fromUtf8("formLayout_3"));
        formLayout_3->setContentsMargins(0, 0, 0, 0);
        label_5 = new QLabel(formLayoutWidget_3);
        label_5->setObjectName(QString::fromUtf8("label_5"));

        formLayout_3->setWidget(0, QFormLayout::LabelRole, label_5);

        description = new QTextEdit(formLayoutWidget_3);
        description->setObjectName(QString::fromUtf8("description"));

        formLayout_3->setWidget(0, QFormLayout::FieldRole, description);

        label_7 = new QLabel(formLayoutWidget_3);
        label_7->setObjectName(QString::fromUtf8("label_7"));

        formLayout_3->setWidget(1, QFormLayout::LabelRole, label_7);

        results = new QTextEdit(formLayoutWidget_3);
        results->setObjectName(QString::fromUtf8("results"));

        formLayout_3->setWidget(1, QFormLayout::FieldRole, results);

        save = new QPushButton(FollowupWidget);
        save->setObjectName(QString::fromUtf8("save"));
        save->setGeometry(QRect(640, 140, 121, 31));
        label_2 = new QLabel(FollowupWidget);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(10, 60, 64, 17));
        label_12 = new QLabel(FollowupWidget);
        label_12->setObjectName(QString::fromUtf8("label_12"));
        label_12->setGeometry(QRect(330, 60, 81, 17));
        label_13 = new QLabel(FollowupWidget);
        label_13->setObjectName(QString::fromUtf8("label_13"));
        label_13->setGeometry(QRect(10, 400, 121, 17));
        back = new QPushButton(FollowupWidget);
        back->setObjectName(QString::fromUtf8("back"));
        back->setGeometry(QRect(640, 80, 121, 51));
        scrollArea = new QScrollArea(FollowupWidget);
        scrollArea->setObjectName(QString::fromUtf8("scrollArea"));
        scrollArea->setGeometry(QRect(10, 420, 621, 211));
        scrollArea->setWidgetResizable(true);
        scrollAreaWidgetContents = new QWidget();
        scrollAreaWidgetContents->setObjectName(QString::fromUtf8("scrollAreaWidgetContents"));
        scrollAreaWidgetContents->setGeometry(QRect(0, 0, 619, 209));
        tableWidget = new QTableWidget(scrollAreaWidgetContents);
        if (tableWidget->columnCount() < 4)
            tableWidget->setColumnCount(4);
        QTableWidgetItem *__qtablewidgetitem = new QTableWidgetItem();
        tableWidget->setHorizontalHeaderItem(0, __qtablewidgetitem);
        QTableWidgetItem *__qtablewidgetitem1 = new QTableWidgetItem();
        tableWidget->setHorizontalHeaderItem(1, __qtablewidgetitem1);
        QTableWidgetItem *__qtablewidgetitem2 = new QTableWidgetItem();
        tableWidget->setHorizontalHeaderItem(2, __qtablewidgetitem2);
        QTableWidgetItem *__qtablewidgetitem3 = new QTableWidgetItem();
        tableWidget->setHorizontalHeaderItem(3, __qtablewidgetitem3);
        tableWidget->setObjectName(QString::fromUtf8("tableWidget"));
        tableWidget->setGeometry(QRect(0, 0, 621, 211));
        tableWidget->setEditTriggers(QAbstractItemView::NoEditTriggers);
        tableWidget->setSelectionMode(QAbstractItemView::SingleSelection);
        tableWidget->setSelectionBehavior(QAbstractItemView::SelectRows);
        tableWidget->setSortingEnabled(true);
        tableWidget->horizontalHeader()->setDefaultSectionSize(140);
        tableWidget->horizontalHeader()->setStretchLastSection(true);
        scrollArea->setWidget(scrollAreaWidgetContents);
        followUpTitle = new QLabel(FollowupWidget);
        followUpTitle->setObjectName(QString::fromUtf8("followUpTitle"));
        followUpTitle->setGeometry(QRect(10, 10, 501, 41));
        label_8 = new QLabel(FollowupWidget);
        label_8->setObjectName(QString::fromUtf8("label_8"));
        label_8->setGeometry(QRect(10, 190, 61, 26));
        status = new QComboBox(FollowupWidget);
        status->setObjectName(QString::fromUtf8("status"));
        status->setGeometry(QRect(110, 190, 211, 26));
        label_6 = new QLabel(FollowupWidget);
        label_6->setObjectName(QString::fromUtf8("label_6"));
        label_6->setGeometry(QRect(330, 190, 81, 26));
        date = new QDateEdit(FollowupWidget);
        date->setObjectName(QString::fromUtf8("date"));
        date->setGeometry(QRect(410, 190, 221, 26));
        followUpNumberLabel = new QLabel(FollowupWidget);
        followUpNumberLabel->setObjectName(QString::fromUtf8("followUpNumberLabel"));
        followUpNumberLabel->setGeometry(QRect(440, 20, 321, 31));

        retranslateUi(FollowupWidget);

        QMetaObject::connectSlotsByName(FollowupWidget);
    } // setupUi

    void retranslateUi(QWidget *FollowupWidget)
    {
        FollowupWidget->setWindowTitle(QApplication::translate("FollowupWidget", "Form", 0, QApplication::UnicodeUTF8));
        label->setText(QApplication::translate("FollowupWidget", "<html><head/><body><p><span style=\" font-weight:600;\">First Name</span></p></body></html>", 0, QApplication::UnicodeUTF8));
        label_3->setText(QApplication::translate("FollowupWidget", "<html><head/><body><p><span style=\" font-weight:600;\">Patient ID #:</span></p></body></html>", 0, QApplication::UnicodeUTF8));
        label_9->setText(QApplication::translate("FollowupWidget", "<html><head/><body><p><span style=\" font-weight:600;\">Last Name</span></p></body></html>", 0, QApplication::UnicodeUTF8));
        label_4->setText(QApplication::translate("FollowupWidget", "<html><head/><body><p><span style=\" font-weight:600;\">PhysicianID</span></p></body></html>", 0, QApplication::UnicodeUTF8));
        label_10->setText(QApplication::translate("FollowupWidget", "<html><head/><body><p><span style=\" font-weight:600;\">First Name</span></p></body></html>", 0, QApplication::UnicodeUTF8));
        label_11->setText(QApplication::translate("FollowupWidget", "<html><head/><body><p><span style=\" font-weight:600;\">Last Name</span></p></body></html>", 0, QApplication::UnicodeUTF8));
        label_5->setText(QApplication::translate("FollowupWidget", "<html><head/><body><p><span style=\" font-size:12pt; font-weight:600; font-style:italic;\">Description</span></p></body></html>", 0, QApplication::UnicodeUTF8));
        label_7->setText(QApplication::translate("FollowupWidget", "<html><head/><body><p><span style=\" font-size:12pt; font-weight:600; font-style:italic;\">Results</span></p></body></html>", 0, QApplication::UnicodeUTF8));
        save->setText(QApplication::translate("FollowupWidget", "Save", 0, QApplication::UnicodeUTF8));
        label_2->setText(QApplication::translate("FollowupWidget", "<html><head/><body><p><span style=\" font-size:12pt; font-weight:600; font-style:italic;\">Patient</span></p></body></html>", 0, QApplication::UnicodeUTF8));
        label_12->setText(QApplication::translate("FollowupWidget", "<html><head/><body><p><span style=\" font-size:12pt; font-weight:600; font-style:italic;\">Physician</span></p></body></html>", 0, QApplication::UnicodeUTF8));
        label_13->setText(QApplication::translate("FollowupWidget", "<html><head/><body><p><span style=\" font-size:12pt; font-weight:600; font-style:italic;\">Follow up List</span></p></body></html>", 0, QApplication::UnicodeUTF8));
        back->setText(QApplication::translate("FollowupWidget", "Back", 0, QApplication::UnicodeUTF8));
        QTableWidgetItem *___qtablewidgetitem = tableWidget->horizontalHeaderItem(0);
        ___qtablewidgetitem->setText(QApplication::translate("FollowupWidget", "Date", 0, QApplication::UnicodeUTF8));
        QTableWidgetItem *___qtablewidgetitem1 = tableWidget->horizontalHeaderItem(1);
        ___qtablewidgetitem1->setText(QApplication::translate("FollowupWidget", "Status", 0, QApplication::UnicodeUTF8));
        QTableWidgetItem *___qtablewidgetitem2 = tableWidget->horizontalHeaderItem(2);
        ___qtablewidgetitem2->setText(QApplication::translate("FollowupWidget", "Description", 0, QApplication::UnicodeUTF8));
        QTableWidgetItem *___qtablewidgetitem3 = tableWidget->horizontalHeaderItem(3);
        ___qtablewidgetitem3->setText(QApplication::translate("FollowupWidget", "Results", 0, QApplication::UnicodeUTF8));
        followUpTitle->setText(QApplication::translate("FollowupWidget", "<html><head/><body><p><br/></p></body></html>", 0, QApplication::UnicodeUTF8));
        label_8->setText(QApplication::translate("FollowupWidget", "<html><head/><body><p><span style=\" font-size:12pt; font-weight:600; font-style:italic;\">Status</span></p></body></html>", 0, QApplication::UnicodeUTF8));
        status->clear();
        status->insertItems(0, QStringList()
         << QApplication::translate("FollowupWidget", "Pending", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("FollowupWidget", "Overdue", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("FollowupWidget", "Results received", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("FollowupWidget", "Complete", 0, QApplication::UnicodeUTF8)
        );
        label_6->setText(QApplication::translate("FollowupWidget", "<html><head/><body><p><span style=\" font-size:12pt; font-weight:600; font-style:italic;\">Due Date</span></p></body></html>", 0, QApplication::UnicodeUTF8));
        followUpNumberLabel->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class FollowupWidget: public Ui_FollowupWidget {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_FOLLOWUPWIDGET_H

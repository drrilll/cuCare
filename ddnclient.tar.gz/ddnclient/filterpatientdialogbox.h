#ifndef FILTERPATIENTDIALOGBOX_H
#define FILTERPATIENTDIALOGBOX_H

#include <QDialog>
#include "maincontroller.h"

class MainController;

namespace Ui {
class filterPatientDialogBox;
}

class filterPatientDialogBox : public QDialog
{
    Q_OBJECT
    
public:
    explicit filterPatientDialogBox(MainController *control, QWidget *parent = 0);
    ~filterPatientDialogBox();

private slots:
    void on_buttonBox_accepted();

private:
    Ui::filterPatientDialogBox *ui;
    MainController *control;
};

#endif // FILTERPATIENTDIALOGBOX_H

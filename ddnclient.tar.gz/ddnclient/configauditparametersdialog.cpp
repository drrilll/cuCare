#include "configauditparametersdialog.h"
#include "ui_configauditparametersdialog.h"

configAuditParametersDialog::configAuditParametersDialog(MainController *control, QWidget *parent) :
    QDialog(parent),
    ui(new Ui::configAuditParametersDialog)
{
    ui->setupUi(this);
    this->control = control;
    QTime time;
    control->getStorage()->getAuditTime(time);
    qDebug("Hello!");
    qDebug(time.toString().toStdString().c_str());
    ui->CATimeEdit->setTime(time);
}

configAuditParametersDialog::~configAuditParametersDialog()
{
    delete ui;
}

void configAuditParametersDialog::on_buttonBox_accepted()
{
    QTime time = ui->CATimeEdit->time();

    AuditProcessController * apController = new AuditProcessController(control);

    apController->setAuditTime(time);

    QMessageBox::information( this, "Success",
                          "Audit set",
                          "OK",0);

    delete apController;

    control->exitConfigAuditParams();
}


void configAuditParametersDialog::on_buttonBox_rejected()
{
     control->exitConfigAuditParams();
}

/********************************************************************************
** Form generated from reading UI file 'mainwindowsa.ui'
**
** Created: Mon Dec 3 23:04:36 2012
**      by: Qt User Interface Compiler version 4.8.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOWSA_H
#define UI_MAINWINDOWSA_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QMainWindow>
#include <QtGui/QPushButton>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindowSA
{
public:
    QWidget *centralwidget;
    QPushButton *manageUserButton;
    QPushButton *configureAuditButton;
    QLabel *label;
    QLabel *userTypeLabel;
    QLabel *loggedInShow;
    QLabel *userTypeShow;
    QLabel *loggedInAsLabel;
    QPushButton *logOutButton;

    void setupUi(QMainWindow *MainWindowSA)
    {
        if (MainWindowSA->objectName().isEmpty())
            MainWindowSA->setObjectName(QString::fromUtf8("MainWindowSA"));
        MainWindowSA->resize(638, 152);
        centralwidget = new QWidget(MainWindowSA);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        manageUserButton = new QPushButton(centralwidget);
        manageUserButton->setObjectName(QString::fromUtf8("manageUserButton"));
        manageUserButton->setEnabled(false);
        manageUserButton->setGeometry(QRect(150, 110, 121, 31));
        configureAuditButton = new QPushButton(centralwidget);
        configureAuditButton->setObjectName(QString::fromUtf8("configureAuditButton"));
        configureAuditButton->setGeometry(QRect(280, 110, 191, 31));
        label = new QLabel(centralwidget);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(30, 10, 311, 51));
        QFont font;
        font.setFamily(QString::fromUtf8("Bitstream Charter"));
        font.setPointSize(24);
        font.setBold(true);
        font.setWeight(75);
        label->setFont(font);
        userTypeLabel = new QLabel(centralwidget);
        userTypeLabel->setObjectName(QString::fromUtf8("userTypeLabel"));
        userTypeLabel->setGeometry(QRect(360, 30, 61, 21));
        loggedInShow = new QLabel(centralwidget);
        loggedInShow->setObjectName(QString::fromUtf8("loggedInShow"));
        loggedInShow->setGeometry(QRect(450, 10, 171, 21));
        userTypeShow = new QLabel(centralwidget);
        userTypeShow->setObjectName(QString::fromUtf8("userTypeShow"));
        userTypeShow->setGeometry(QRect(450, 30, 151, 21));
        loggedInAsLabel = new QLabel(centralwidget);
        loggedInAsLabel->setObjectName(QString::fromUtf8("loggedInAsLabel"));
        loggedInAsLabel->setGeometry(QRect(360, 10, 91, 21));
        logOutButton = new QPushButton(centralwidget);
        logOutButton->setObjectName(QString::fromUtf8("logOutButton"));
        logOutButton->setGeometry(QRect(360, 50, 261, 31));
        MainWindowSA->setCentralWidget(centralwidget);

        retranslateUi(MainWindowSA);

        QMetaObject::connectSlotsByName(MainWindowSA);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindowSA)
    {
        MainWindowSA->setWindowTitle(QApplication::translate("MainWindowSA", "MainWindow", 0, QApplication::UnicodeUTF8));
        manageUserButton->setText(QApplication::translate("MainWindowSA", "Manage Users", 0, QApplication::UnicodeUTF8));
        configureAuditButton->setText(QApplication::translate("MainWindowSA", "Configure Audit Parameters", 0, QApplication::UnicodeUTF8));
        label->setText(QApplication::translate("MainWindowSA", "Welcome to cuCare", 0, QApplication::UnicodeUTF8));
        userTypeLabel->setText(QApplication::translate("MainWindowSA", "<html><head/><body><p><span style=\" font-weight:600; font-style:italic;\">I am a(n):</span></p></body></html>", 0, QApplication::UnicodeUTF8));
        loggedInShow->setText(QString());
        userTypeShow->setText(QString());
        loggedInAsLabel->setText(QApplication::translate("MainWindowSA", "<html><head/><body><p><span style=\" font-weight:600; font-style:italic;\">Logged in as:</span></p></body></html>", 0, QApplication::UnicodeUTF8));
        logOutButton->setText(QApplication::translate("MainWindowSA", "Log out", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class MainWindowSA: public Ui_MainWindowSA {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOWSA_H

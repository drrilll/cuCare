/********************************************************************************
** Form generated from reading UI file 'configauditparametersdialog.ui'
**
** Created: Mon Dec 3 22:32:11 2012
**      by: Qt User Interface Compiler version 4.8.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_CONFIGAUDITPARAMETERSDIALOG_H
#define UI_CONFIGAUDITPARAMETERSDIALOG_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QDialog>
#include <QtGui/QDialogButtonBox>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QTimeEdit>

QT_BEGIN_NAMESPACE

class Ui_configAuditParametersDialog
{
public:
    QDialogButtonBox *buttonBox;
    QLabel *CATLabel;
    QTimeEdit *CATimeEdit;

    void setupUi(QDialog *configAuditParametersDialog)
    {
        if (configAuditParametersDialog->objectName().isEmpty())
            configAuditParametersDialog->setObjectName(QString::fromUtf8("configAuditParametersDialog"));
        configAuditParametersDialog->resize(283, 112);
        configAuditParametersDialog->setContextMenuPolicy(Qt::DefaultContextMenu);
        buttonBox = new QDialogButtonBox(configAuditParametersDialog);
        buttonBox->setObjectName(QString::fromUtf8("buttonBox"));
        buttonBox->setGeometry(QRect(70, 60, 181, 32));
        buttonBox->setOrientation(Qt::Horizontal);
        buttonBox->setStandardButtons(QDialogButtonBox::Cancel|QDialogButtonBox::Ok);
        CATLabel = new QLabel(configAuditParametersDialog);
        CATLabel->setObjectName(QString::fromUtf8("CATLabel"));
        CATLabel->setGeometry(QRect(30, 20, 101, 20));
        CATimeEdit = new QTimeEdit(configAuditParametersDialog);
        CATimeEdit->setObjectName(QString::fromUtf8("CATimeEdit"));
        CATimeEdit->setGeometry(QRect(130, 20, 121, 26));

        retranslateUi(configAuditParametersDialog);
        QObject::connect(buttonBox, SIGNAL(rejected()), configAuditParametersDialog, SLOT(reject()));

        QMetaObject::connectSlotsByName(configAuditParametersDialog);
    } // setupUi

    void retranslateUi(QDialog *configAuditParametersDialog)
    {
        configAuditParametersDialog->setWindowTitle(QApplication::translate("configAuditParametersDialog", "Set Up the Audit Time", 0, QApplication::UnicodeUTF8));
        CATLabel->setText(QApplication::translate("configAuditParametersDialog", "<html><head/><body><p><span style=\" font-size:12pt; font-weight:600; font-style:italic;\">Audit Time:</span></p></body></html>", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class configAuditParametersDialog: public Ui_configAuditParametersDialog {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_CONFIGAUDITPARAMETERSDIALOG_H

#include "consultationcontroller.h"

ConsultationController::ConsultationController(MainController *control)
{
    this->control = control;
    consults = control->getConsults();
}

errorType ConsultationController::getConsultationList(){
    consults->clear();
    errorType t;
    Patient* p = *(control->getCurrentPatient());
    if(control->isFiltering()){
        t = control->getStorage()->getConsultationList(*p, *consults, control->getPhysIDFilter(),control->getStatusFilter());
    }
    else{
        t = control->getStorage()->getConsultationList(*p, *consults, 0);
    }
    return t;
}

errorType ConsultationController::saveConsultation(bool update){
    errorType t;
    Consultation *currentConsult = *(control->getCurrentConsult());
    if (update){
       t = control->getStorage()->updateConsultation(*currentConsult);
    }else{
       t = control->getStorage()->saveNewConsultation(*currentConsult);
    }
    return t;
}

errorType ConsultationController::getFollowupList(){

    errorType t;
    if(control->isFiltering()){
        t = control->getStorage()->getFollowupList(**(control->getCurrentConsult()), *(control->getFollowups()), control->getPhysIDFilter(), control->getStatusFilter());
    }
    else{
        t = control->getStorage()->getFollowupList(**(control->getCurrentConsult()), *(control->getFollowups()), 0);
    }
    return t;
}

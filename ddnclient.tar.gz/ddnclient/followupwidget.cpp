#include "followupwidget.h"
#include "ui_followupwidget.h"

FollowupWidget::FollowupWidget(MainController *control,QWidget *parent) :
    QWidget(parent),
    ui(new Ui::FollowupWidget)
{
    ui->setupUi(this);
    this->control = control;
    this->followups = control->getFollowups();
    currentPatient = this->control->getCurrentPatient();
    currentConsult = control->getCurrentConsult();
    currentFollowup = control->getCurrentFollowup();
    storage = control->getStorage();
    //initializeWithNewConsultation();

}

FollowupWidget::~FollowupWidget()
{
    delete ui;
}

void FollowupWidget::initializeWithNewConsultation(){

        if(control->getUser()->getType()==1){
            ui->patientfname->setEnabled(false);
            ui->patientlname->setEnabled(false);
            ui->patientID->setEnabled(false);
            ui->physfname->setEnabled(false);
            ui->physlname->setEnabled(false);
            ui->physID->setEnabled(false);
            ui->description->setEnabled(false);
            ui->date->setEnabled(false);
        }
        else{
            ui->patientfname->setEnabled(false);
            ui->patientlname->setEnabled(false);
            ui->patientID->setEnabled(false);
            ui->physfname->setEnabled(false);
            ui->physlname->setEnabled(false);
            ui->physID->setEnabled(false);
            ui->description->setEnabled(true);
            ui->date->setEnabled(true);
        }


    QString num;
    qDebug("here at initializer");

    //storage->getFollowupList(*(new Consultation()),*followups);
    //control->getCurrentPatient();
    qDebug("storage ok");
    if ((*currentPatient)==0){
        qDebug("currentPatient is 0");
    }

    qDebug("setPatientID");
    ui->patientID->setText(num.setNum((*currentPatient)->getPatientID()));
    qDebug("setPatientfname") ;
    ui->patientfname->setText((*currentPatient)->getFirstName());
    qDebug("setPatientlname") ;
    ui->patientlname->setText((*currentPatient)->getLastName());
    qDebug("set physID") ;
    ui->physID->setText(num.setNum((*currentConsult)->getPhysID()));
    qDebug("physID: %s",num.toStdString().c_str()) ;
    qDebug("set physfname") ;
    ui->physfname->setText((*currentConsult)->getPhysFirstName());
    qDebug("set physlname") ;
    ui->physlname->setText((*currentConsult)->getPhysLastName());
    qDebug("done initializer") ;

    QString consultNumber;
    consultNumber.setNum((*currentConsult)->getConsultID());
    QString followUpDisplay;
    followUpDisplay.append("Follow-Up for Consultation ID #").append(consultNumber);
    QFont font;
    font.setPointSize(24);
    font.setBold(true);

    ui->followUpTitle->setFont(font);
    ui->followUpTitle->setText(followUpDisplay);

    populateFollowupTable();
}

void FollowupWidget::on_save_clicked()
{
    QString message;
    QString button;
    bool update = false;
    if ((*currentFollowup)==0){
        message.append("Save new follow-up?");
        button.append("Save");
        (*currentFollowup)= new Followup();
    }else{
        message.append("Update follow-up?");
        button.append("Update");
        update = true;
    }
    if (QMessageBox::information( this, "Follow-up",
                              message,
                              button,"Cancel", 0,1)==1){
        return;
    }
    QString description(ui->description->toPlainText());
    QString results(ui->results->toPlainText());

    qDebug("Consultation # from followupwindow: %d", (*currentConsult)->getConsultID());
    qDebug("there is a current consult");

    (*currentFollowup)->setConsultID((*currentConsult)->getConsultID());
    (*currentFollowup)->setDate(ui->date->date());
    (*currentFollowup)->setDescription(description);
    (*currentFollowup)->setResults(results);
    (*currentFollowup)->setStatus((Status)(ui->status->currentIndex()+1));
    qDebug("Results: %s", (*currentFollowup)->getResults().toStdString().c_str());


    errorType t;

    FollowupController *followUpControl = new FollowupController(control);
    t = followUpControl->saveFollowup(update);

    if (t==OK){
        button.append(" succeeded");
    }else{
        button.append(" failed");
    }
    QMessageBox::information( this, "follow-up",
                                      button,
                                          "OK",0);
    populateFollowupTable();

    delete followUpControl;
}



void FollowupWidget::on_tableWidget_clicked(const QModelIndex &index)
{
    (*currentFollowup)=&(*followups)[index.row()];
    populateFollowupForm();

    QString followUpNumber;
    followUpNumber.setNum((*currentFollowup)->getFollowupID());
    QString followUpNumberDisplay;
    followUpNumberDisplay.append("FOLLOWUP ID #").append(followUpNumber);
    QFont font;
    font.setPointSize(18);
    font.setBold(true);

    ui->followUpNumberLabel->setAlignment(Qt::AlignRight);
    ui->followUpNumberLabel->setFont(font);
    ui->followUpNumberLabel->setText(followUpNumberDisplay);



}

//private

void FollowupWidget::populateFollowupForm(){
    if ((*currentFollowup) == 0){
        QMessageBox::warning( this, "Developer error",
                                  "No currentFollowup available.",
                                    "OK",0);
    }
    QString num;
    ui->patientfname->setText((*currentPatient)->getFirstName());
    ui->patientlname->setText((*currentPatient)->getLastName());
    ui->patientID->setText(num.setNum((*currentPatient)->getPatientID()));

    ui->physfname->setText((*currentConsult)->getPhysFirstName());
    ui->physlname->setText((*currentConsult)->getPhysLastName());
    ui->physID->setText(num.setNum((*currentConsult)->getPhysID()));

    ui->description->setText((*currentFollowup)->getDescription());
    ui->results->setText((*currentFollowup)->getResults());
    ui->status->setCurrentIndex((*currentFollowup)->getStatus()-1);

    ui->date->setDate((*currentFollowup)->getDate());

    //enum Status {pending, overdue, results_received, complete};

}

void FollowupWidget::populateFollowupTable(){

    Followup *fup;
    QString num;
    qDebug("Populating followups: %d", followups->size());
    ui->tableWidget->setRowCount(followups->size());
    QString status;
    QTableWidgetItem *item;
    for (int i = 0; i < followups->size(); i ++){
        fup = &(*followups)[i];
        // date status description results
       //QTableWidgetItem item(consult->)
        item = new QTableWidgetItem(fup->getDate().toString());
        item->setFlags(item->flags() ^ Qt::ItemIsEditable);
        ui->tableWidget->setItem(i,0,item);
        status.clear();
        switch(fup->getStatus()){
        case pending:
            status.append("pending");
            break;
        case overdue:
            status.append("overdue");
            break;
        case results_received:
            status.append("results_received");
            break;
        case complete:
            status.append("complete");
            break;
        }

        item = new QTableWidgetItem(status);
        item->setFlags(item->flags() ^ Qt::ItemIsEditable);
         ui->tableWidget->setItem(i,1,item);
         item = new QTableWidgetItem(fup->getDescription());
         item->setFlags(item->flags() ^ Qt::ItemIsEditable);
         ui->tableWidget->setItem(i,2,item);
         item = new QTableWidgetItem(fup->getResults());
         item->setFlags(item->flags() ^ Qt::ItemIsEditable);
         ui->tableWidget->setItem(i,3,item);
    }
}

void FollowupWidget::on_back_clicked()
{
    control->exitFollowupWindow();
}

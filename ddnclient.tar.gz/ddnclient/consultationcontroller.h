#ifndef CONSULTATIONCONTROLLER_H
#define CONSULTATIONCONTROLLER_H
#include <maincontroller.h>

//class MainController;

class ConsultationController
{
public:
    ConsultationController(MainController * control);

    errorType getConsultationList();

    errorType saveConsultation(bool update);

    errorType getFollowupList();



private:
    MainController * control;
    QList<Consultation> * consults;
};

#endif // CONSULTATIONCONTROLLER_H

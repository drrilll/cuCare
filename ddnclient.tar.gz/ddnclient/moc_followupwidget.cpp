/****************************************************************************
** Meta object code from reading C++ file 'followupwidget.h'
**
** Created: Mon Dec 3 23:51:28 2012
**      by: The Qt Meta Object Compiler version 63 (Qt 4.8.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "followupwidget.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'followupwidget.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 63
#error "This file was generated using the moc from 4.8.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_FollowupWidget[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
       3,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: signature, parameters, type, tag, flags
      22,   16,   15,   15, 0x08,
      58,   15,   15,   15, 0x08,
      76,   15,   15,   15, 0x08,

       0        // eod
};

static const char qt_meta_stringdata_FollowupWidget[] = {
    "FollowupWidget\0\0index\0"
    "on_tableWidget_clicked(QModelIndex)\0"
    "on_save_clicked()\0on_back_clicked()\0"
};

void FollowupWidget::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Q_ASSERT(staticMetaObject.cast(_o));
        FollowupWidget *_t = static_cast<FollowupWidget *>(_o);
        switch (_id) {
        case 0: _t->on_tableWidget_clicked((*reinterpret_cast< const QModelIndex(*)>(_a[1]))); break;
        case 1: _t->on_save_clicked(); break;
        case 2: _t->on_back_clicked(); break;
        default: ;
        }
    }
}

const QMetaObjectExtraData FollowupWidget::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject FollowupWidget::staticMetaObject = {
    { &QWidget::staticMetaObject, qt_meta_stringdata_FollowupWidget,
      qt_meta_data_FollowupWidget, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &FollowupWidget::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *FollowupWidget::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *FollowupWidget::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_FollowupWidget))
        return static_cast<void*>(const_cast< FollowupWidget*>(this));
    return QWidget::qt_metacast(_clname);
}

int FollowupWidget::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 3)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 3;
    }
    return _id;
}
QT_END_MOC_NAMESPACE

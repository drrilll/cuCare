#ifndef CLIENT_H
#define CLIENT_H

#include <QTcpSocket>
#include "custore.h"
#include "../entityobjects/user.h"
#include <QHostAddress>

class Client
{
public:
    Client(QString);

    QByteArray & startWrite(errorType &error);
    void finishWrite();
    QByteArray & startRead();
    void finishRead();
    void setIPAddress(QString);

private:
    QTcpSocket socket;
    QByteArray buffer;
    QHostAddress add;
};

#endif // CLIENT_H

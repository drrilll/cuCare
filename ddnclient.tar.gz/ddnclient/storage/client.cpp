#include "client.h"
#include <iostream>
#include <QHostAddress>

using namespace std;

Client::Client(QString ip)
{
    qDebug(ip.toStdString().c_str());
    add.setAddress(ip);
    qDebug(add.toString().toStdString().c_str());
}

QByteArray &Client:: startWrite(errorType &error){
    buffer.clear();

    //Ethernet Adapter local area connection
    qDebug("=====");
    qDebug(add.toString().toStdString().c_str());
    socket.connectToHost(add, 60000);
    int rc = socket.waitForConnected(30);
    if (!rc){
        cout << "Could not connect to server"<<endl;
        error = generalError;
    }else{
        error = OK;
    }
    return buffer;
}

void Client::finishWrite(){
    socket.write(buffer);
    socket.flush();
}

QByteArray & Client::startRead(){
    buffer.clear();
    int rc = socket.waitForReadyRead(-1);
    if(!rc){
        cout << "Network timed out"<<endl;
    }
    buffer = socket.readAll();
    return buffer;
}

void Client::finishRead(){
    socket.disconnectFromHost();
}

#ifndef PATIENTCONTROLLER_H
#define PATIENTCONTROLLER_H
#include <storage/custore.h>
#include <maincontroller.h>

class PatientController
{
public:
    PatientController(MainController *control);

    errorType savePatient(bool update);

private:
    MainController* control;
    Patient *currentPatient;
};

#endif // PATIENTCONTROLLER_H

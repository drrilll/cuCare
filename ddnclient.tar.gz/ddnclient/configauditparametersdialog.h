#ifndef CONFIGAUDITPARAMETERSDIALOG_H
#define CONFIGAUDITPARAMETERSDIALOG_H

#include <QDialog>
#include "maincontroller.h"
#include "auditprocesscontroller.h"

namespace Ui {
class configAuditParametersDialog;
}

class configAuditParametersDialog : public QDialog
{
    Q_OBJECT
    
public:
    explicit configAuditParametersDialog(MainController *control, QWidget *parent = 0);
    ~configAuditParametersDialog();
    
private slots:
    void on_buttonBox_accepted();

    void on_buttonBox_rejected();

private:
    Ui::configAuditParametersDialog *ui;
    MainController *control;
};

#endif // CONFIGAUDITPARAMETERSDIALOG_H

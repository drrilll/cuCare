#include "logincontroller.h"

LoginController::LoginController(MainController * control)
{
    this->control = control;
    this->user = control->getUser();
}

errorType LoginController::getUser(QString a){
    errorType t = control->getStorage()->getUser(a, *user);
    return t;
}

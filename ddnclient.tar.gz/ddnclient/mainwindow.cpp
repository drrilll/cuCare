#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(MainController *control, QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    this->control = control;
    this->user = control->getUser();
    this->storage = control->getStorage();
    this->patients = control->getPatients();


    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
    delete user;
}

void MainWindow::open(){
    qDebug("============ MainWindow::open() ===================");
    this->user = control->getUser();
    qDebug(user->getUserName().toStdString().c_str());
    ui->loggedInShow->setText(user->getUserName());
    if(user->getType()==1) {ui->userTypeShow->setText("Assistant Administrator");}
    if(user->getType()==2) {ui->userTypeShow->setText("Physician");}


    QString title;

    title.append("cuCare logged in as ").append(user->getUserName());
    this->setWindowTitle(title);

    this->setFixedSize(686,246);


    show();
}

void MainWindow::swapWidget(QWidget *widget){
    tempwidget = ui->centralwidget;
    ui->centralwidget = widget;
}

void MainWindow::on_newpatient_clicked()
{
    control->setCurrentPatient(0);
    patients->clear();
    control->openPatientWindow();
}

//search methods

void MainWindow::on_searchhcard_clicked()
{
    patients->clear();
    errorType t = storage->searchPatientbyHealthcard(ui->healthcard->text(), *patients);
    if (t!=OK){
        QMessageBox::information( this, "Patient Search",
                                  "Database error. Is the server running?",
                                    "OK",0);
        return;
    }
    if (patients->size() == 0){
        QMessageBox::information( this, "Patient Search",
                                  "No patients found by that criteria",
                                    "OK",0);
        return;
    }
    control->openPatientWindow();
}

void MainWindow::on_searchfname_clicked()
{
    patients->clear();
    errorType t = storage->searchPatientbyFirstName(ui->fname->text(), *patients);
    qDebug("mainwindow searched patient first name");
    if (t!=OK){
        QMessageBox::information( this, "Patient Search",
                                  "Database error. Is the server running?",
                                    "OK",0);
        return;
    }
    if (patients->size() == 0){
        QMessageBox::information( this, "Patient Search",
                                  "No patients found by that criteria",
                                    "OK",0);
        return;
    }
    control->openPatientWindow();
}

void MainWindow::on_searchlname_clicked()
{
    qDebug("searching last name");
    patients->clear();
    qDebug("making query");
    errorType t = storage->searchPatientbyLastName(ui->lname->text(), *patients);
    if (t!=OK){
        QMessageBox::information( this, "Patient Search",
                                  "Database error. Is the server running?",
                                    "OK",0);
        return;
    }
    if (patients->size() == 0){
        QMessageBox::information( this, "Patient Search",
                                  "No patients found by that criteria",
                                    "OK",0);
        return;
    }
    qDebug("opening window");
    control->openPatientWindow();
}

void MainWindow::on_searchfullname_clicked()
{
    patients->clear();
    errorType t = storage->searchPatientbyFullName(ui->lname->text(),ui->fname->text(), *patients);
    if (t!=OK){
        QMessageBox::information( this, "Patient Search",
                                  "Database error. Is the server running?",
                                    "OK",0);
        return;
    }
    if (patients->size() == 0){
        QMessageBox::information( this, "Patient Search",
                                  "No patients found by that criteria",
                                    "OK",0);
        return;
    }
    control->openPatientWindow();
}



void MainWindow::on_filterPatientList_clicked()
{
    control->openFilterPatientDialogBox();
}

void MainWindow::on_logOutButton_clicked()
{
    control->logout();
}

void MainWindow::on_actionPick_a_colour_triggered()
{
    QColorDialog d;
    d.exec();
    control->setColor(d.getColor());
}

#ifndef MAINCONTROLLER_H
#define MAINCONTROLLER_H

#include "storage/custore.h"
#include "mainwindow.h"
#include "patientwindow.h"
#include "logindialog.h"
#include "consultwindow.h"
#include "followupwindow.h"
#include "followupwidget.h"
#include "filterpatientdialogbox.h"
#include "mainwindowsa.h"
#include "configauditparametersdialog.h"
#include <QColor>

class LoginDialog;
class MainWindow;
class PatientSearchDialog;
class PatientWindow;
class ConsultWindow;
class FollowupWindow;
class FollowupWidget;
class filterPatientDialogBox;
class MainWindowSA;
class configAuditParametersDialog;

class MainController
{
public:
    MainController();
    ~MainController();

    //setters
    void setPatients(QList<Patient> *patients);
    void setConsults(QList<Consultation> *consults);
    void setCurrentPatient(Patient* patient);
    void setCurrentConsult(Consultation* consult);
    void setColor(QColor color);

    //filtering setters

    void setFilter(qint32 physIDFilter, Status statusFilter);
    void removeFilter();

    //getters
    QList<Patient> *getPatients();
    QList<Consultation> *getConsults();
    QList<Followup> *getFollowups();
    Patient ** getCurrentPatient();
    Consultation ** getCurrentConsult();
    Followup ** getCurrentFollowup();
    cuStore * getStorage();
    User * getUser();
    QColor * getFilterColour();

    MainWindow * getMainWindow();


    //filtering getters
    bool isFiltering();
    qint32 getPhysIDFilter();
    Status getStatusFilter();

    //etc
    void addPatient(Patient* pat);

    //window callbacks
    void loginSuccess();
    void exitPatientWindow(); 
    void exitConsultWindow();
    void exitFollowupWindow();
    void exitConfigAuditParams();
    void openPatientWindow();
    void openConsultWindow();
    void openFollowupWindow();
    void openFilterPatientDialogBox();
    void openConfigureAuditParametersDialogBox();

    void logout();


private:
    cuStore * storage;
    User * user;
    LoginDialog * login;
    MainWindow * mainWindow;
    PatientWindow * patwindow;
    PatientSearchDialog *psearchdialog;
    ConsultWindow *consultwindow;
    FollowupWindow *followupwindow;
    FollowupWidget *followupwidget;
    filterPatientDialogBox *filterPatientDB;
    MainWindowSA * mainWindowSA;
    configAuditParametersDialog * configAPDialog;

    Patient * currentPatient;
    QList<Patient> *patients;
    QList<Consultation> *consults;
    Consultation * currentConsult;
    QList<Followup> *followups;
    Followup * currentFollowup;

    QColor * filterColour;

    //filtering parameters
    bool filter;
    Status statusFilter;
    qint32 physIDFilter;

};

#endif // MAINCONTROLLER_H

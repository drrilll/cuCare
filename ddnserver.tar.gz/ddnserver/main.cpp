#include <QApplication>
#include "server.h"
#include "serverdialog.h"
#include "cuCareDB/custorage.h"


int main(int argc, char *argv[])
{
   QApplication app(argc, argv);
   //Client client;
   Server server;
   ServerDialog sd;
   sd.show();
   return app.exec();
}
